package com.zapp.gatewayservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
